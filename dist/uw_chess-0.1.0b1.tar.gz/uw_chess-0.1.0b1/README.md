<h1 align="center">Undr Wolf<br>♖ Voice-Controlled Blindfold Chess ♖</h1>
Undr Wolf is a chess game designed for players seeking to enhance their skills in blindfold chess. This project utilizes ASCII and classic2D for chessboard rendering, text-to-speech and speech-to-text to create a chess game that can be entirely navigated through voice commands. Current testing uses Stockfish chess-engine as chess bot and to evaluate game score.

#### Follow the journey on https://www.youtube.com/@UndrWolf

![Image Alt text](/project_images/2023-12-04_gameplay.png "POC")

## Installation
First proof of concept is available as a python package 2023-12-11

## Usage
2023-12-11

## Documentation
2023-12-11

